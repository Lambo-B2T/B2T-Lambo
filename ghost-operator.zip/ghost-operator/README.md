# 👻 Ghost Operator

Système d'outils IA pour lancer un business e-commerce dématérialisé — budget zéro, automatisation maximale.

## 🚀 Accès rapide

👉 **[Ouvrir le Dashboard](https://[votre-pseudo].github.io/ghost-operator/)**

## 🛠 Modules disponibles

| Module | Statut | Description |
|--------|--------|-------------|
| 🎯 Niche Finder | ✅ LIVE | Analyse IA des meilleures niches dropshipping |
| 🔭 Niche Explorer | ✅ LIVE | Explorez et comparez les niches par univers |
| 🏪 Boutique Builder | 🔜 Bientôt | Guide création boutique Shopify |
| 📱 Content Engine | 🔜 Bientôt | Génération contenu TikTok/Instagram |
| 🤖 SAV Automatisé | 🔜 Bientôt | Agent IA service client |
| 🏛 Structure Juridique | 🔜 Bientôt | Guide LLC Wyoming + Wise + Stripe |

## 📁 Structure du projet

```
ghost-operator/
├── index.html          ← Dashboard principal
├── niche-finder.html   ← Module 01
├── niche-explorer.html ← Module 01b
└── README.md
```

## 🔧 Installation locale

1. Clonez ce repo
2. Ouvrez `index.html` dans votre navigateur
3. Aucune dépendance requise

## 🌐 Hébergement GitHub Pages

1. Settings → Pages
2. Source : Deploy from branch → main → / (root)
3. Votre URL : `https://[pseudo].github.io/ghost-operator/`

---

*Système privé — Ghost Operator 2026*
